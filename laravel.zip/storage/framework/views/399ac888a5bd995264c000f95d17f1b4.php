<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Data Siswa</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
        <style>
            @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700;800&display=swap');
            * {
                font-family: 'Poppins', sans-serif;
            }

            .container {
                text-align: center;
            }

            h1 {
                font-weight: 600;
            }

            .alert {
                text-align: center;
            }
        </style>
    </head>
    <body>
        <div class="container"><br><br>
            <div class="card">
                <div class="row">
                    <div class="col-8">
                        <br><h1>Data Siswa</h1>
                    </div>
                    <div class="col-2">
                        <br><a href="<?php echo e(route('create')); ?>" class="btn btn-primary">Tambah Data</a>
                    </div>
                </div>
                <div class="card-body">
                    <div class="notif">
                        <?php if(session('success')): ?>
                            <div class="alert alert-success alert-dismissible fade show" role="alert" style="width: 50%;">
                                <?php echo e(session('success')); ?>

                                <a data-bs-dismiss="alert"></a>
                            </div>
                        <?php endif; ?>
                    </div>

                    <table class="table table-striped table-hover">
                        <thead>
                            <tr class="table-dark">
                                <th scope="col">No</th>
                                <th scope="col">Nama</th>
                                <th scope="col">Kelas</th>
                                <th scope="col">Jurusan</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <?php
                            $no = 1;
                        ?>
                        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tbody>
                            <tr>
                                <td><?php echo e($no++); ?></td>
                                <td><?php echo e($student['nama']); ?></td>
                                <td><?php echo e($student['kelas']); ?></td>
                                <td><?php echo e($student['jurusan']); ?></td>
                                <td>
                                    <a href="<?php echo e(route('detail', $student->id)); ?>" class="btn btn-success">Detail</a>
                                    <a href="<?php echo e(route('edit', $student->id)); ?>" class="btn btn-warning">Edit</a>
                                    <a href="" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#deleteModal-<?php echo e($student->id); ?>">Hapus</a>
                                </td>
                            </tr>
                        </tbody>

                        <div class="modal fade" id="deleteModal-<?php echo e($student->id); ?>" tabindex="-1" aria-labelledby="deleteModalLabel-<?php echo e($student->id); ?>" aria-hidden="true">
                            <div class="modal-content">
                                <div class="modal-dialog">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="deleteModalLabel-<?php echo e($student->id); ?>">Konfirmasi Hapus</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <p>Apakah Anda yakin ingin menghapus data <strong><?php echo e($student['nama']); ?></strong>?</p>
                                    </div>
                                    <div class="modal-footer">
                                        <form action="<?php echo e(route('delete', $student->id)); ?>" method="" class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="btn btn-danger">Hapus</button>
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    </body>
</html><?php /**PATH C:\laragon\www\RPL57\LaravelPack\resources\views/datasiswa.blade.php ENDPATH**/ ?>