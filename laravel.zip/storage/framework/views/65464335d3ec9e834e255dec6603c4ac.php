<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Dashboard')); ?></div>

                <di class="card-body">
                    <div class="notif">
                        <?php if(session('success')): ?>
                            <div class="alert alert-success alert-dismissible fade show" role="alert" style="width: 100%;">
                                <?php echo e(session('success')); ?>

                                <a data-bs-dismiss="alert"></a>
                            </div>
                        <?php endif; ?>

                        <?php if(session('info')): ?>
                            <div class="alert alert-info alert-dismissible fade show" role="alert" style="width: 100%;">
                                <?php echo e(session('info')); ?>

                                <a data-bs-dismiss="alert"></a>
                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="row">
                        <div class="col-8">
                            <h1>Data Siswa</h1>
                        </div>
                        <div class="col-3">
                            <a href="<?php echo e(route('create')); ?>" class="btn btn-primary">Tambah Data</a>
                        </div>
                    </div>

                    <table class="table table-striped table-hover">
                        <thead>
                            <tr class="table-dark">
                                <th scope="col">No</th>
                                <th scope="col">Nama</th>
                                <th scope="col">Kelas</th>
                                <th scope="col">Jurusan</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <?php
                            $no = 1;
                        ?>
                        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tbody>
                            <tr>
                                <td><?php echo e($no++); ?></td>
                                <td><?php echo e($student['nama']); ?></td>
                                <td><?php echo e($student['kelas']); ?></td>
                                <td><?php echo e($student['jurusan']); ?></td>
                                <td class="aksi">
                                    <a href="<?php echo e(route('detail', $student->id)); ?>" class="btn btn-success">Detail</a>
                                    <a href="<?php echo e(route('edit', $student->id)); ?>" class="btn btn-warning">Edit</a>
                                    <form action="<?php echo e(route('delete', $student->id)); ?>">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger">Hapus</button>
                                    </form>
                                </td>
                            </tr>
                        </tbody>      
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\RPL57\LaravelPack\resources\views/home.blade.php ENDPATH**/ ?>