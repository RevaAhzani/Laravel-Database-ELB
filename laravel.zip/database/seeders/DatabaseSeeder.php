<?php

namespace Database\Seeders;

use App\Models\User;
use App\Models\students;
// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        // User::factory(10)->create();

        // students::create([
        //     'nama' => 'Vivi',
        //     'kelas' => '11',
        //     'jurusan' => 'RPL'
        // ]);

        // students::create([
        //     'nama' => 'Keisha',
        //     'kelas' => '11',
        //     'jurusan' => 'RPL'
        // ]);
    }
}
